//For the last programming assignment, we will be working with graph abstraction data type. 
//Graphs consist of vertices(nodes) and edges which connect the vertices.  Edges can have labels. 
//An adjacency list where there are 1-10 vertices, and each node will represent an edge connecting a
//vertex to other vertices. It is a linear linked list. The data structure we will be working with 
//is an array of linear linked list. The array represents all the vertices. The edge list is represented 
//by each linear linked list if there is a connection between the vertices. 
#include <cstring>
#include <iostream>
#include <cctype>
using namespace std;

struct vertex
{
    ~vertex();
    char * trail_name;
    struct node * head;
};
struct node
{
    ~node();
    int trail_length;
    char * trail_difficulty_level;
    vertex * adjacent;
    node * next;

};
class table
{
    public:
        table(int size = 5);
        ~table(void);
        int insert_vertex( char * a_trail);
        int insert_edge( char * current_vertex, char * to_attach, int length,  char * difficulty);
        int copy_vertex( vertex * current_vertex, vertex * to_attach);
        int find_location( char * key_value);
        int display_adjacent(char * key_value);
        int display_all();
        int delete_all();
    private:
        vertex * adjacency_list;
        int list_size;
};


