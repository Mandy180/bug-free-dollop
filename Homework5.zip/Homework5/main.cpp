#include "program5.h"
int main()
{
    int user_input = 0;
    table Mount_Tabor;
    while(user_input ==  0)
    {
        cout << "Main Menu: " << "\n1. ADD A NEW TRAIL: " << "\n2. INSERT A CONNECTION " << "\n3. DISPLAY ADJACENT VERTICES " << "\n4. DISPLAY ALL " << endl;
        cin >> user_input;
        cin.ignore(100, '\n');

        if( user_input == 1)
        {
            char name[100];
            cout << "PLEASE ENTER THE NAME OF THE TRAIL: " << endl;
            cin.get(name, 100, '\n');
            cin.ignore(100, '\n');

           Mount_Tabor.insert_vertex(name);
        }
        if(user_input == 2)
        {
            char name1[100];
            char name2[100];
            int length = 0;
            char level[100];

            cout << "PLEASE ENTER THE NAME OF THE FIRST TRAIL: " << endl;
            cin.get(name1, 100, '\n');
            cin.ignore(100, '\n');


            cout << "PLEASE ENTER THE NAME OF THE SECOND TRAIL: " << endl;
            cin.get(name2, 100, '\n');
            cin.ignore(100, '\n');

            cout << "PLEASE ENTER THE LENGTH OF THE FIRST TO SECOND TRAIL: " << endl;
            cin >> length;
            cin.ignore(100, '\n');

            cout << "PLEASE ENTER THE DIFFICULTY LEVEL OF THE FIRST TO SECOND TRAIL: " << endl;
            cin.get(level,100, '\n');
            cin.ignore(100, '\n');
            
            Mount_Tabor.insert_edge(name1, name2, length, level);
            Mount_Tabor.insert_edge(name2, name1, length, level);

        }
        if(user_input == 3)
        {
            char name[100];
            cout << "PLEASE ENTER THE TRAIL NAME " << endl;
            cin.get(name, 100, '\n');
            cin.ignore(100, '\n');
            Mount_Tabor.display_adjacent(name);

        }
        if(user_input == 4)
        {
            Mount_Tabor.display_all();
        }




        cout << "To return back to the main menu please enter 0 if not enter 100 " << endl;
        cin >> user_input;
        cin.ignore(100, '\n');

    }










    return 0;
}
