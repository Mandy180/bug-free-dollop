#include "program5.h"

table::table(int size)
{
    adjacency_list = new vertex[size];
    for( int i = 0; i < size; ++i)
    {
        adjacency_list[i].head = NULL;
        adjacency_list[i].trail_name = NULL;
    }
    list_size = size;
}
table::~table()
{
    delete_all();
    delete [] adjacency_list;
    list_size = 0;
}
int table::delete_all()
{
    for( int i = 0; i < list_size; ++i)
    {
        node * temp = adjacency_list[i].head;
        while(temp)
        {
            node * temp2 = temp -> next;
            delete temp;
            temp = temp2;
        }

    }
    return 1;
}
vertex::~vertex()
{
    if(trail_name)
    {
        delete [] trail_name;
        trail_name = NULL;
    }
}
node::~node()
{
    if(trail_difficulty_level)
    {
        delete [] trail_difficulty_level;
        trail_difficulty_level = NULL;
    }
    trail_length = 0;
}
int table::insert_vertex( char * a_trail)
{
    for( int i = 0; i < list_size; ++i)
    {
        if(adjacency_list[i].trail_name == NULL)
        {
            adjacency_list[i].trail_name = new char[strlen(a_trail) +1];
            strcpy(adjacency_list[i].trail_name, a_trail);
            return 1;
        }
    }
    return 1;
}
int table::insert_edge( char * current_vertex, char * to_attach, int length,  char * difficulty)
{

    int current = find_location(current_vertex);
    int to_add = find_location(to_attach);
    if(adjacency_list[current].head == NULL)
    {
        adjacency_list[current].head = new node;
        adjacency_list[current].head -> adjacent = &adjacency_list[to_add];
        adjacency_list[current].head -> trail_length = length;
        adjacency_list[current].head -> trail_difficulty_level = new char[strlen(difficulty) +1];
        strcpy( adjacency_list[current].head -> trail_difficulty_level, difficulty); 
        adjacency_list[current].head -> next = NULL; 
    }
    else
    {
        node * temp = new node;
        temp -> adjacent = &adjacency_list[to_add];
        temp -> trail_length = length;
        temp -> trail_difficulty_level = new char[strlen(difficulty) +1];
        strcpy( temp -> trail_difficulty_level, difficulty);
        temp -> next = adjacency_list[current].head;
        adjacency_list[current].head = temp;
    }
    return 1;

}
int table::find_location( char * key_value)
{
    for( int i = 0; i < list_size; ++i)
    {
        if(strcmp(adjacency_list[i].trail_name, key_value) == 0)
            return i;
    }
    return -1;
}
int table::display_adjacent( char * key_value)
{
    int current = find_location(key_value);
    node * temp = adjacency_list[current].head;
    while(temp)
    {
        cout << "Name of the adjacent trail : " << temp ->adjacent -> trail_name << endl;
        cout << "Length of the trail: " << temp -> trail_length << endl;
        cout << "Level of difficulty: " << temp -> trail_difficulty_level << endl;
        temp = temp -> next;
    }


    return 0;
}
int table::display_all()
{
    for( int i = 0; i < list_size; ++i)
    {
        if(!adjacency_list[i].trail_name)
            return 0;
        cout << "NAME OF THE TRAIL: " << adjacency_list[i].trail_name << endl;
           node * temp = adjacency_list[i].head;
           while(temp)
           {
               display_adjacent(adjacency_list[i].trail_name);
                temp = temp -> next;
            }
    }



    return 0;
}


